$(document).ready(function() {
    var flickrApiUrl = "https://api.flickr.com/services/feeds/photos_public.gne?jsoncallback=?";

    $.getJSON(flickrApiUrl, {
        id: "147817942@N03",
        tags: "spice, oil, tea, coffee",
        tagmode: "any",
        format : "json"
    }).done(function(data) {
        var html = "";
        var col = 1;
        html += "<div class=\"container\">";
        $(data.items).each(function(index, element) {
            console.log(element);
            if(col == 1){
                html += "<div class=\"row\">";
            }
            html += "<div class=\"col-md-3 mb-3\">" +
                        "<div class=\"card\" id=\"product-card\">" +
                            "<div class=\"card-body\">" +
                                "<img id=\"flickr-img\" src=\"" + element.media.m + "\">" +
                            "</div>" +
                        "</div>" +
                    "</div>";
            if(col == 4){
                html += "</div>";
                col = 0;
            }
            col++;
        });
        html += "</div>";
        console.log(html);
        $("#flickr-pics").append(html);
    }).fail(function() {
        alert("Ajax call failed");
    });
});